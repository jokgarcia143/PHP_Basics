<?php
 $databaseHost = 'localhost';
 $databaseName = 'employee_management';
 $databaseUsername = 'admin';
 $databasePassword = '+Lz2N}M9';
 
 $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
?>
<?php
    include_once("inc/config.php");
    
    //Array
    $result = mysqli_query($mysqli, "SELECT * FROM employees");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="add.html">Add New Data</a><br/><br/>

<table width='80%' border=0>
    <tr>
        <td>Employee ID</td>
        <td>First Name</td>
        <td>Last Name</td>
        <td>Email</td>
        <td>Contact Number</td>
    </tr>
    <?php
        while($data = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>".$data['employee_id']."</td>";
            echo "<td>".$data['first_name']."</td>";
            echo "<td>".$data['last_name']."</td>";
            echo "<td>".$data['email']."</td>";
            echo "<td>".$data['contact_no']."</td>";
            echo "<td><a href=\"edit.php?employee_id=$data[employee_id]\">Edit</a> | <a href=\"delete.php?employee_id=$data[employee_id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
            echo "</tr>";
        }
    ?>
</table>

    
</body>
</html>
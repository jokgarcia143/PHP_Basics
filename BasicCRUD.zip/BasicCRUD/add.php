<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>
</head>
<body>
    <?php
      include_once("inc/config.php");
      if(isset($_POST['Submit'])){
        $employee_id = mysqli_real_escape_string($mysqli, $_POST['employee_id']);
        $first_name = mysqli_real_escape_string($mysqli, $_POST['first_name']);
        $last_name = mysqli_real_escape_string($mysqli, $_POST['last_name']);
        $email = mysqli_real_escape_string($mysqli, $_POST['email']);
        $contact_no = mysqli_real_escape_string($mysqli, $_POST['contact_no']);

        if(empty($employee_id)){
            if(empty($employee_id)) {
                echo "<font color='red'>ID field is empty.</font><br/>";
            }

            echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
        }
        else{
            $result = mysqli_query($mysqli, "INSERT INTO employees(employee_id, first_name, last_name, email,contact_no) VALUES ('$employee_id','$first_name','$last_name','$email','$contact_no')");
            //display success message
		    echo "<font color='green'>Data added successfully.";
		    echo "<br/><a href='index.php'>View Result</a>";
        }
      }
    ?>
</body>
</html>